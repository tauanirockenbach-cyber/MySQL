
use estoquecomercial;

CREATE TABLE Itens_Estoque(
idItem INT NOT NULL AUTO_INCREMENT,
descricaoItem VARCHAR(200),
setorItem VARCHAR(200),
precoVendaItem DOUBLE(9,2),
estoqueItem INT,
PRIMARY KEY (idItem)
);

INSERT INTO Itens_Estoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
('Suco de Laranja','Bebidas','7.50',250),
('Macarrão 1kg','Alimentos','5.20',180),
('Sabão em pó','Limpeza','12.90',90),
('Café Torrado','Alimentos','15.80',120),
('Iogurte Natural','Laticínios','4.30',350),
('Biscoito Integral',NULL,'3.90',210),
('Molho de Tomate','Alimentos','2.80',500);

SELECT*FROM Itens_Estoque

SELECT descricaoItem, precoVendaItem, setorItem
FROM Itens_Estoque
where descricaoItem <> 'Iogurte Natural';

select precoVendaItem, estoqueItem
from Itens_Estoque
WHERE descricaoItem = 'Biscoito Integral' and setorItem is NULL;

SELECT descricaoItem, setorItem
FROM Itens_Estoque
where idItem = 1 or precoVendaItem > 30;

SELECT descricaoItem
FROM Itens_Estoque 
WHERE precoVendaItem BETWEEN 1.00 and 7.50;

SELECT precoVendaItem
FROM Itens_Estoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios', 'Praia','Alimentos');

SELECT*FROM Itens_Estoque
WHERE setorItem NOT IN ('Limpeza','Bebidas','Laticínios');

SELECT*FROM Itens_Estoque
WHERE descricaoItem LIKE'%Sa%';
set@minha_idade=25;
set@nome_produto = 'pc';
SELECT (precoVendaItem * @minha_idade)AS Total_Estoque
FROM Itens_Estoque;
ORDER BY precoVendaItem DESC;

SELECT COUNT(descricaoItem)
FROM Itens_Estoque
WHERE descricaoItem LIKE'%t%';

SELECT AVG (precoVendaItem)
FROM Itens_Estoque;

SELECT SUM (estoqueItem) 
FROM Itens_Estoque;

SELECT MIN(precoVendaItem)
FROM Itens_Estoque
SELECT MAX(precoVendaItem)
FROM Itens_Estoque;

-- 1) verificar quantidade de itens por setor;
-- 2) verificar média valor produto por setor;
-- 3) verificar valor min e max por setor;

SELECT estoqueItem, COUNT (setorItem)
FROM Itens_Estoque
GROUP BY estoqueItem;

SELECT setorItem, AVG (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem;

SELECT setorItem, MIN (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem;

SELECT setorItem, MAX (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem;
