/* 2026-05-13 15:39:06 [732 ms] */ 
SELECT * FROM categoria LIMIT 100;
/* 2026-05-13 16:11:27 [505 ms] */ 
CREATE DATABASE ecommerce;
/* 2026-05-13 16:11:27 [363 ms] */ 
USE ecommerce;
/* 2026-05-13 16:11:28 [604 ms] */ 
CREATE TABLE categoria (
    id INT AUTO_INCREMENT,
    nome VARCHAR(100),
    descricao TEXT,
    PRIMARY KEY (id)
);
/* 2026-05-13 16:11:45 [388 ms] */ 
CREATE TABLE produto (
    id INT AUTO_INCREMENT,
    nome VARCHAR(150),
    descricao TEXT,
    preco DECIMAL(10,2),
    estoque INT,
    categoria_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);
/* 2026-05-13 16:12:12 [362 ms] */ 
USE ecommerce;
/* 2026-05-13 16:14:08 [400 ms] */ 
INSERT INTO categoria (nome, descricao) VALUES 
('Eletrônicos', 'Dispositivos eletrônicos e gadgets'),
('Roupas', 'Vestuário masculino e feminino'),
('Livros', 'Livros físicos e técnicos'),
('Eletrodomésticos', 'Aparelhos para casa'),
('Esportes', 'Equipamentos esportivos');
/* 2026-05-13 16:14:11 [374 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES 
('Smartphone XYZ', 'Smartphone com 128GB', 1500.00, 50, 1),
('Camiseta Algodão', 'Camiseta básica preta', 49.90, 200, 2),
('Livro SQL Master', 'Guia completo de SQL', 89.90, 100, 3),
('Geladeira Frost Free', 'Geladeira 400 litros', 3500.00, 20, 4),
('Bola de Futebol', 'Bola de campo oficial', 120.00, 75, 5);
/* 2026-05-13 16:14:19 [983 ms] */ 
SELECT * FROM categoria LIMIT 100;
/* 2026-05-13 16:14:26 [364 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:37:01 [724 ms] */ 
USE ecommerce;
/* 2026-05-13 16:37:06 [375 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:37:10 [1880 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:38:33 [1366 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id=2;
/* 2026-05-13 16:38:36 [366 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:38:42 [356 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:38:43 [355 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:40:38 [357 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id=2;
/* 2026-05-13 16:40:40 [355 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:41:38 [362 ms] */ 
UPDATE produto
SET categoria_id=3;
/* 2026-05-13 16:41:39 [354 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:50:43 [358 ms] */ 
USE ecommerce;
/* 2026-05-13 16:51:03 [360 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES 
('Smartphone XYZ', 'Smartphone com 128GB', 1500.00, 50, 1),
('Camiseta Algodão', 'Camiseta básica preta', 49.90, 200, 2),
('Livro SQL Master', 'Guia completo de SQL', 89.90, 100, 3),
('Geladeira Frost Free', 'Geladeira 400 litros', 3500.00, 20, 4),
('Bola de Futebol', 'Bola de campo oficial', 120.00, 75, 5);
/* 2026-05-13 16:51:08 [363 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:51:10 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:51:54 [380 ms] */ 
DELETE FROM `produto` WHERE () OR() OR() OR() OR();
/* 2026-05-13 16:52:08 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:53:01 [357 ms] */ 
DELETE FROM `produto` WHERE () OR() OR() OR() OR();
/* 2026-05-13 16:53:38 [364 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'M%';
/* 2026-05-13 16:53:43 [985 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:54:06 [360 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 16:54:08 [361 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:17 [366 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=500;
/* 2026-05-13 16:57:19 [359 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:59:44 [359 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=0;
/* 2026-05-13 16:59:48 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:59:59 [365 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 17:00:07 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:00:56 [359 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=500;
/* 2026-05-13 17:01:02 [359 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:01:36 [385 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE preco>=0;
/* 2026-05-13 17:01:39 [364 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:02:50 [359 ms] */ 
UPDATE produto
SET estoque = 30
WHERE id =0;
/* 2026-05-13 17:02:53 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:03:23 [358 ms] */ 
UPDATE produto
SET estoque = 30
WHERE id =0;
/* 2026-05-13 17:03:31 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:03:40 [358 ms] */ 
UPDATE produto
SET estoque = 50
WHERE id =0;
/* 2026-05-13 17:03:42 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:04:05 [379 ms] */ 
UPDATE produto
SET estoque = estoque + 50
WHERE id =0;
/* 2026-05-13 17:04:09 [358 ms] */ 
SELECT*FROM produto;
