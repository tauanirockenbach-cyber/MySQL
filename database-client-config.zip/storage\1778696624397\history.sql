/* 2026-05-13 15:39:06 [732 ms] */ 
SELECT * FROM categoria LIMIT 100;
/* 2026-05-13 16:11:27 [505 ms] */ 
CREATE DATABASE ecommerce;
/* 2026-05-13 16:11:27 [363 ms] */ 
USE ecommerce;
/* 2026-05-13 16:11:28 [604 ms] */ 
CREATE TABLE categoria (
    id INT AUTO_INCREMENT,
    nome VARCHAR(100),
    descricao TEXT,
    PRIMARY KEY (id)
);
/* 2026-05-13 16:11:45 [388 ms] */ 
CREATE TABLE produto (
    id INT AUTO_INCREMENT,
    nome VARCHAR(150),
    descricao TEXT,
    preco DECIMAL(10,2),
    estoque INT,
    categoria_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);
/* 2026-05-13 16:12:12 [362 ms] */ 
USE ecommerce;
/* 2026-05-13 16:14:08 [400 ms] */ 
INSERT INTO categoria (nome, descricao) VALUES 
('Eletrônicos', 'Dispositivos eletrônicos e gadgets'),
('Roupas', 'Vestuário masculino e feminino'),
('Livros', 'Livros físicos e técnicos'),
('Eletrodomésticos', 'Aparelhos para casa'),
('Esportes', 'Equipamentos esportivos');
/* 2026-05-13 16:14:11 [374 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES 
('Smartphone XYZ', 'Smartphone com 128GB', 1500.00, 50, 1),
('Camiseta Algodão', 'Camiseta básica preta', 49.90, 200, 2),
('Livro SQL Master', 'Guia completo de SQL', 89.90, 100, 3),
('Geladeira Frost Free', 'Geladeira 400 litros', 3500.00, 20, 4),
('Bola de Futebol', 'Bola de campo oficial', 120.00, 75, 5);
/* 2026-05-13 16:14:19 [983 ms] */ 
SELECT * FROM categoria LIMIT 100;
/* 2026-05-13 16:14:26 [364 ms] */ 
SELECT * FROM produto LIMIT 100;
/* 2026-05-13 16:37:01 [724 ms] */ 
USE ecommerce;
/* 2026-05-13 16:37:06 [375 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:37:10 [1880 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:38:33 [1366 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id=2;
/* 2026-05-13 16:38:36 [366 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:38:42 [356 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:38:43 [355 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:40:38 [357 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE id=2;
/* 2026-05-13 16:40:40 [355 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:41:38 [362 ms] */ 
UPDATE produto
SET categoria_id=3;
/* 2026-05-13 16:41:39 [354 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:50:43 [358 ms] */ 
USE ecommerce;
/* 2026-05-13 16:51:03 [360 ms] */ 
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES 
('Smartphone XYZ', 'Smartphone com 128GB', 1500.00, 50, 1),
('Camiseta Algodão', 'Camiseta básica preta', 49.90, 200, 2),
('Livro SQL Master', 'Guia completo de SQL', 89.90, 100, 3),
('Geladeira Frost Free', 'Geladeira 400 litros', 3500.00, 20, 4),
('Bola de Futebol', 'Bola de campo oficial', 120.00, 75, 5);
/* 2026-05-13 16:51:08 [363 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE id=2;
/* 2026-05-13 16:51:10 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:51:54 [380 ms] */ 
DELETE FROM `produto` WHERE () OR() OR() OR() OR();
/* 2026-05-13 16:52:08 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:53:01 [357 ms] */ 
DELETE FROM `produto` WHERE () OR() OR() OR() OR();
/* 2026-05-13 16:53:38 [364 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'M%';
/* 2026-05-13 16:53:43 [985 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:54:06 [360 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 16:54:08 [361 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:57:17 [366 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=500;
/* 2026-05-13 16:57:19 [359 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:59:44 [359 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=0;
/* 2026-05-13 16:59:48 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 16:59:59 [365 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 17:00:07 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:00:56 [359 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=500;
/* 2026-05-13 17:01:02 [359 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:01:36 [385 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE preco>=0;
/* 2026-05-13 17:01:39 [364 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:02:50 [359 ms] */ 
UPDATE produto
SET estoque = 30
WHERE id =0;
/* 2026-05-13 17:02:53 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:03:23 [358 ms] */ 
UPDATE produto
SET estoque = 30
WHERE id =0;
/* 2026-05-13 17:03:31 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:03:40 [358 ms] */ 
UPDATE produto
SET estoque = 50
WHERE id =0;
/* 2026-05-13 17:03:42 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:04:05 [379 ms] */ 
UPDATE produto
SET estoque = estoque + 50
WHERE id =0;
/* 2026-05-13 17:04:09 [358 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:07:22 [359 ms] */ 
UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
/* 2026-05-13 17:07:24 [357 ms] */ 
UPDATE produto
SET estoque = estoque + 50
WHERE id =0;
/* 2026-05-13 17:07:25 [359 ms] */ 
UPDATE produto
SET categoria_id=3
WHERE preco>=500;
/* 2026-05-13 17:07:28 [362 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:07:52 [381 ms] */ 
UPDATE produto
SET
    descricao='Notebook com SSD e 16GB de RAM',
    estoque=15
WHERE id=4;
/* 2026-05-13 17:08:00 [367 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 17:08:41 [359 ms] */ 
UPDATE produto
SET
    nome = 'pc usado - notebook',
    descricao='Notebook com SSD e 16GB de RAM',
    estoque=15
WHERE id=4;
/* 2026-05-13 17:08:42 [363 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:17:35 [4093 ms] */ 
DELETE FROM produto WHERE id = 1;
/* 2026-05-13 18:17:39 [720 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:21:09 [455 ms] */ 
INSERT INTO produto ()
values (DEFAULT, 'telefone','telefone legal',50.00,200,1);
/* 2026-05-13 18:21:12 [360 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:29:36 [1917 ms] */ 
DELETE from produto
WHERE nome = 'telefone' and id = 1;
/* 2026-05-13 18:29:47 [713 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:29:55 [1110 ms] */ 
DELETE from produto
WHERE nome = 'telefone' and id = 11;
/* 2026-05-13 18:29:58 [356 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:33:36 [1039 ms] */ 
DELETE from produto
WHERE nome = 'Camiseta Algodão' or id = 2;
/* 2026-05-13 18:33:41 [1025 ms] */ 
SELECT*FROM produto;
/* 2026-05-13 18:34:49 [382 ms] */ 
CREATE DATABASE estoquecomercial;
/* 2026-05-13 18:35:42 [356 ms] */ 
use estoquecomercial;
/* 2026-05-13 18:37:22 [638 ms] */ 
CREATE TABLE Itens_Estoque(
idItem INT NOT NULL AUTO_INCREMENT,
descricaoItem VARCHAR(200),
setorItem VARCHAR(200),
precoVendaItem DOUBLE(9,2),
estoqueItem INT,
PRIMARY KEY (idItem)
);
/* 2026-05-13 18:37:29 [381 ms] */ 
INSERT INTO Itens_Estoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
('Suco de Laranja','Bebidas','7.50',250),
('Macarrão 1kg','Alimentos','5.20',180),
('Sabão em pó','Limpeza','12.90',90),
('Café Torrado','Alimentos','15.80',120),
('Iogurte Natural','Laticínios','4.30',350),
('Biscoito Integral',NULL,'3.90',210),
('Molho de Tomate','Alimentos','2.80',500);
/* 2026-05-13 18:38:10 [357 ms] */ 
SELECT*FROM Itens_Estoque;
/* 2026-05-13 18:54:32 [357 ms] */ 
use estoquecomercial;
/* 2026-05-13 18:54:37 [359 ms] */ 
INSERT INTO Itens_Estoque
(descricaoItem,setorItem,precoVendaItem,estoqueItem)VALUES
('Suco de Laranja','Bebidas','7.50',250),
('Macarrão 1kg','Alimentos','5.20',180),
('Sabão em pó','Limpeza','12.90',90),
('Café Torrado','Alimentos','15.80',120),
('Iogurte Natural','Laticínios','4.30',350),
('Biscoito Integral',NULL,'3.90',210),
('Molho de Tomate','Alimentos','2.80',500);
/* 2026-05-13 18:54:41 [357 ms] */ 
SELECT*FROM Itens_Estoque;
/* 2026-05-13 18:54:44 [357 ms] */ 
SELECT setorItem FROM Itens_Estoque
where descricaoItem  = 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 18:54:54 [357 ms] */ 
SELECT*FROM Itens_Estoque;
/* 2026-05-13 18:56:23 [358 ms] */ 
SELECT descricaoItem, precoVendaItem, setorItem
FROM Itens_Estoque
where descricaoItem  = 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 18:56:36 [357 ms] */ 
SELECT descricaoItem, precoVendaItem, setorItem
FROM Itens_Estoque
where descricaoItem <> 'Iogurte Natural' LIMIT 100;
/* 2026-05-13 19:02:30 [361 ms] */ 
select precoVendaItem, estoqueItem
from Itens_Estoque
WHERE descricaoItem = 'Biscoito Integral' and setorItem is NULL LIMIT 100;
/* 2026-05-13 19:07:42 [2866 ms] */ 
SELECT descricaoItem, setorItem
FROM Itens_Estoque
where idItem = 1 or precoVendaItem > 30 LIMIT 100;
/* 2026-05-13 19:10:27 [357 ms] */ 
SELECT descricaoItem
FROM Itens_Estoque 
WHERE NOT precoVendaItem = 7.50 LIMIT 100;
/* 2026-05-13 19:13:57 [358 ms] */ 
SELECT descricaoItem
FROM Itens_Estoque 
WHERE precoVendaItem BETWEEN 1.00 and 7.50 LIMIT 100;
/* 2026-05-13 19:17:13 [357 ms] */ 
SELECT*FROM Itens_Estoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios');
/* 2026-05-13 19:17:59 [357 ms] */ 
SELECT*FROM Itens_Estoque
WHERE setorItem NOT IN ('Limpeza','Bebidas','Laticínios');
/* 2026-05-13 19:19:07 [360 ms] */ 
SELECT*FROM Itens_Estoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios', 'Praia',' Cama Banho');
/* 2026-05-13 19:20:15 [357 ms] */ 
SELECT precoVendaItem
FROM Itens_Estoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios', 'Praia',' Cama Banho') LIMIT 100;
/* 2026-05-13 19:21:30 [1611 ms] */ 
SELECT precoVendaItem
FROM Itens_Estoque
WHERE setorItem IN ('Limpeza','Bebidas','Laticínios', 'Praia','Alimentos') LIMIT 100;
/* 2026-05-13 19:28:11 [358 ms] */ 
use estoquecomercial;
/* 2026-05-13 19:28:15 [356 ms] */ 
SELECT*FROM Itens_Estoque
WHERE descricaoItem LIKE'%Sa%';
/* 2026-05-13 19:33:24 [357 ms] */ 
use estoquecomercial;
/* 2026-05-13 19:34:10 [361 ms] */ 
SELECT (precoVendaItem * estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:34:18 [357 ms] */ 
SELECT (precoVendaItem / estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:34:25 [361 ms] */ 
SELECT (precoVendaItem + estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:34:30 [359 ms] */ 
SELECT (precoVendaItem - estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:34:39 [357 ms] */ 
SELECT (precoVendaItem / estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:38:19 [357 ms] */ 
SELECT (precoVendaItem + estoqueItem)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:39:36 [1008 ms] */ 
SELECT (precoVendaItem *2 )AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:42:12 [372 ms] */ 
set@minha_idade=25;
/* 2026-05-13 19:42:22 [357 ms] */ 
SELECT*FROM Itens_Estoque;
/* 2026-05-13 19:42:56 [359 ms] */ 
SELECT (precoVendaItem * @minha_idade)AS Total_Estoque
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 19:45:19 [358 ms] */ 
SELECT*FROM Itens_Estoque
ORDER BY precoVendaItem DESC;
/* 2026-05-13 20:01:49 [1636 ms] */ 
use estoquecomercial;
/* 2026-05-13 20:01:53 [377 ms] */ 
SELECT COUNT(descricaoItem)
FROM Itens_Estoque
WHERE descricaoItem LIKE'%Molho%' LIMIT 100;
/* 2026-05-13 20:02:23 [362 ms] */ 
SELECT COUNT(descricaoItem)
FROM Itens_Estoque
WHERE descricaoItem LIKE'%a%' LIMIT 100;
/* 2026-05-13 20:02:44 [1105 ms] */ 
SELECT COUNT(descricaoItem)
FROM Itens_Estoque
WHERE descricaoItem LIKE'%j%' LIMIT 100;
/* 2026-05-13 20:02:47 [359 ms] */ 
SELECT COUNT(descricaoItem)
FROM Itens_Estoque
WHERE descricaoItem LIKE'%t%' LIMIT 100;
/* 2026-05-13 20:05:51 [372 ms] */ 
SELECT AVG (precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:09:46 [360 ms] */ 
SELECT SUM (estoqueItem) 
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:11:13 [359 ms] */ 
SELECT MIN(precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:11:29 [362 ms] */ 
SELECT MAX(precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:22:52 [1190 ms] */ 
use estoquecomercial;
/* 2026-05-13 20:22:56 [377 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
WHERE estoqueItem LIKE'%t%' LIMIT 100;
/* 2026-05-13 20:23:07 [358 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
WHERE estoqueItem LIMIT 100;
/* 2026-05-13 20:24:16 [357 ms] */ 
SELECT AVG (setorItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:24:23 [364 ms] */ 
SELECT AVG (precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:25:20 [359 ms] */ 
SELECT AVG (precoVendaItem)
FROM Itens_Estoque
WHERE estoqueItem LIMIT 100;
/* 2026-05-13 20:25:44 [358 ms] */ 
SELECT AVG (precoVendaItem)
FROM Itens_Estoque
WHERE setorItem LIMIT 100;
/* 2026-05-13 20:26:56 [357 ms] */ 
SELECT MIN(precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:26:58 [356 ms] */ 
SELECT MAX(precoVendaItem)
FROM Itens_Estoque LIMIT 100;
/* 2026-05-13 20:27:25 [356 ms] */ 
SELECT MIN(precoVendaItem)
FROM Itens_Estoque
WHERE setorItem LIMIT 100;
/* 2026-05-13 20:28:29 [359 ms] */ 
SELECT MIN(estoqueItem)
FROM Itens_Estoque
WHERE precoVendaItem LIMIT 100;
/* 2026-05-13 20:29:04 [358 ms] */ 
SELECT MAX(estoqueItem)
FROM Itens_Estoque
WHERE precoVendaItem LIMIT 100;
/* 2026-05-13 20:36:33 [2519 ms] */ 
use estoquecomercial;
/* 2026-05-13 20:36:37 [1324 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
WHERE estoqueItem LIMIT 100;
/* 2026-05-13 20:38:58 [408 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
WHERE estoqueItem
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:39:36 [359 ms] */ 
SELECT MAX(estoqueItem)
FROM Itens_Estoque
WHERE precoVendaItem
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:39:50 [359 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
WHERE estoqueItem
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:40:57 [357 ms] */ 
SELECT COUNT(setorItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:41:36 [359 ms] */ 
SELECT setorItem, COUNT(*) qtd
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:42:32 [358 ms] */ 
SELECT AVG (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:44:45 [1006 ms] */ 
SELECT MAX(estoqueItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:44:46 [358 ms] */ 
SELECT MIN(estoqueItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:46:20 [359 ms] */ 
use estoquecomercial;
/* 2026-05-13 20:51:05 [360 ms] */ 
SELECT setorItem, AVG (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:51:07 [359 ms] */ 
SELECT setorItem, MIN (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:51:09 [358 ms] */ 
SELECT setorItem, MAX (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 20:57:27 [714 ms] */ 
use estoquecomercial;
/* 2026-05-13 20:57:31 [1154 ms] */ 
SELECT setorItem, COUNT(*) qtd
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:01:14 [358 ms] */ 
SELECT estoqueItem, COUNT (setorItem)
FROM Itens_Estoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:01:34 [361 ms] */ 
SELECT estoqueItem, COUNT (descricaoItem)
FROM Itens_Estoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:01:50 [359 ms] */ 
SELECT estoqueItem, COUNT (setorItem)
FROM Itens_Estoque
GROUP BY estoqueItem LIMIT 100;
/* 2026-05-13 21:03:02 [359 ms] */ 
SELECT setorItem, AVG (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:10:32 [702 ms] */ 
use estoquecomercial;
/* 2026-05-13 21:10:34 [353 ms] */ 
SELECT setorItem, MIN (precoVendaItem)
FROM Itens_Estoque
GROUP BY setorItem LIMIT 100;
/* 2026-05-13 21:16:13 [1858 ms] */ 
use estoquecomercial;
