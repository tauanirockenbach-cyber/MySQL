-- comando UPDATE

CREATE DATABASE ecommerce;
USE ecommerce;

CREATE TABLE categoria (
    id INT AUTO_INCREMENT,
    nome VARCHAR(100),
    descricao TEXT,
    PRIMARY KEY (id)
);
CREATE TABLE produto (
    id INT AUTO_INCREMENT,
    nome VARCHAR(150),
    descricao TEXT,
    preco DECIMAL(10,2),
    estoque INT,
    categoria_id INT,
    PRIMARY KEY (id),
    FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);
-- Inserindo dados na tabela categoria
INSERT INTO categoria (nome, descricao) VALUES 
('Eletrônicos', 'Dispositivos eletrônicos e gadgets'),
('Roupas', 'Vestuário masculino e feminino'),
('Livros', 'Livros físicos e técnicos'),
('Eletrodomésticos', 'Aparelhos para casa'),
('Esportes', 'Equipamentos esportivos');

-- Inserindo dados na tabela produto (assumindo os IDs gerados de 1 a 5 para as categorias)
INSERT INTO produto (nome, descricao, preco, estoque, categoria_id) VALUES 
('Smartphone XYZ', 'Smartphone com 128GB', 1500.00, 50, 1),
('Camiseta Algodão', 'Camiseta básica preta', 49.90, 200, 2),
('Livro SQL Master', 'Guia completo de SQL', 89.90, 100, 3),
('Geladeira Frost Free', 'Geladeira 400 litros', 3500.00, 20, 4),
('Bola de Futebol', 'Bola de campo oficial', 120.00, 75, 5);
SELECT * FROM categoria;
SELECT * FROM produto;
UPDATE produto
SET categoria_id=2
WHERE id=2;

SELECT*FROM produto

UPDATE produto
SET categoria_id=2
WHERE nome LIKE'B%';
UPDATE produto
SET estoque = estoque + 50
WHERE id =0;

UPDATE produto
SET categoria_id=3
WHERE preco>=500;